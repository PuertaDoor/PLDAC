# Implementation of the experiments in the paper SPLADE v2: Sparse Lexical and
# Expansion Model for Information Retrieval, (Thibault Formal, Carlos Lassance,
# Benjamin Piwowarski, Stéphane Clinchant), 2021
# https://arxiv.org/abs/2109.10086

import logging

from experimaestro.launcherfinder import find_launcher

from xpmir.learning.optim import (
    TensorboardService,
)
from experimaestro import experiment, setmeta
from xpmir.distributed import DistributedHook
from xpmir.learning.learner import Learner
from xpmir.letor.learner import ValidationListener
from xpmir.index.sparse import (
    SparseRetriever,
    SparseRetrieverIndexBuilder,
)
from xpmir.papers.cli import paper_command
from xpmir.learning.batchers import PowerAdaptativeBatcher
from xpmir.neural.dual import DenseDocumentEncoder, DenseQueryEncoder
from xpmir.rankers.standard import BM25
from xpmir.neural.splade import spladeV2_max, spladeV2_doc
from xpmir.papers.results import PaperResults
from xpmir.datasets.adapters import RetrieverBasedCollection
from xpmir.papers.helpers.splade import splade_sampler
from xpmir.rankers.full import FullRetriever
from xpmir.documents.samplers import RandomDocumentSampler
from .configuration import SPLADE
import xpmir.interfaces.anserini as anserini
from xpmir.models import AutoModel
from xpmir.index.faiss import IndexBackedFaiss, FaissRetriever

from xpmir.measures import R, nDCG, AP, RR

from xpmir.datasets.adapters import RandomFold

from datamaestro import prepare_dataset

from xpmir.letor.samplers import PointwiseCanardModelBasedSampler
from xpmir.letor.trainers.pointwise import CanardTrainer, MSELoss

from xpmir.evaluation import Evaluations


logging.basicConfig(level=logging.INFO)

# Run by:
# $ xpmir papers splade spladeV2 --configuration config_name experiment/


def run(
    xp: experiment, cfg: SPLADE, tensorboard_service: TensorboardService
) -> PaperResults:
    """SPLADE model"""

    gpu_launcher_learner = find_launcher(cfg.splade.requirements)
    gpu_launcher_retrieval = find_launcher(cfg.retrieval.requirements)
    cpu_launcher_index = find_launcher(cfg.indexation.requirements)
    gpu_launcher_index = find_launcher(cfg.indexation.training_requirements)

    device = cfg.device
    random = cfg.random

    documents = prepare_dataset("irds.trec-cast.v1.documents")

    ds_val_all, tests = RandomFold.folds(seed=123, sizes=[.98, .02], dataset=prepare_dataset("irds.trec-cast.v1.2020.judged"))

    tests = Evaluations(tests, [R @ 10, AP @ 10, nDCG @ 3, nDCG @ 10, RR])

    # -----The baseline------
    # BM25
    base_model = BM25().tag("model", "bm25")

    index = anserini.IndexCollection(documents=documents, storePositions=True, storeDocvectors=True, storeContents=True, threads=8).submit(launcher=gpu_launcher_index)

    bm25_retriever = anserini.AnseriniRetriever(
        k=1000, index=index, model=base_model
    )

    tests.evaluate_retriever(bm25_retriever, cpu_launcher_index)

    # tas-balanced
    tasb = AutoModel.load_from_hf_hub("xpmir/tas-balanced").tag(
        "model", "tasb"
    )  # create a scorer from huggingface

    tasb_index = IndexBackedFaiss(
        indexspec=cfg.indexation.indexspec,
        device=device,
        normalize=False,
        documents=documents,
        sampler=RandomDocumentSampler(
            documents=documents,
            max_count=cfg.indexation.faiss_max_traindocs,
        ),  # Just use a fraction of the dataset for training
        encoder=DenseDocumentEncoder(scorer=tasb),
        batchsize=2048,
        batcher=PowerAdaptativeBatcher(),
        hooks=[
            setmeta(DistributedHook(models=[tasb.encoder, tasb.query_encoder]), True)
        ],
    ).submit(launcher=gpu_launcher_index)

    tasb_retriever = FaissRetriever(
        index=tasb_index,
        topk=1000,
        encoder=DenseQueryEncoder(scorer=tasb),
    )

    tests.evaluate_retriever(tasb_retriever, gpu_launcher_index)

    # Building the validation set of the splade
    # We cannot use the full document dataset to build the validation set.

    # This one could be generic for both sparse and dense methods
    index_ds_val_all = anserini.IndexCollection(documents=ds_val_all.documents, storePositions=True, storeDocvectors=True, storeContents=True, threads=8).submit(launcher=gpu_launcher_index)

    ds_val = RetrieverBasedCollection(
        dataset=ds_val_all,
        retrievers=[
            anserini.AnseriniRetriever(
                k=cfg.retrieval.retTopK, index=index_ds_val_all, model=base_model
            ),
        ],
    ).submit(launcher=gpu_launcher_index)

    # Base retrievers for validation
    # It retrieve all the document of the collection with score 0
    base_retriever_full = FullRetriever(documents=ds_val.documents)

    # -----Learning to rank component preparation part-----
    # Define the model and the flop loss for regularization
    # Model of class: DotDense()
    # The parameters are the regularization coeff for the query and document
    if cfg.splade.model == "splade_max":
        spladev2, flops = spladeV2_max(
            cfg.splade.lambda_q,
            cfg.splade.lambda_d,
            cfg.splade.lamdba_warmup_steps,
        )
    elif cfg.splade.model == "splade_doc":
        spladev2, flops = spladeV2_doc(
            cfg.splade.lambda_q,
            cfg.splade.lambda_d,
            cfg.splade.lamdba_warmup_steps,
        )
    else:
        raise NotImplementedError

    # define the trainer
    pointwise_trainer_flops = CanardTrainer(
        hooks=[flops],
        batcher=PowerAdaptativeBatcher(),
        sampler=PointwiseCanardModelBasedSampler(dataset=prepare_dataset("com.github.aagohary.canard").train),
        batch_size=cfg.splade.optimization.batch_size,
        lossfn=MSELoss(),
        encoder=spladev2.encoder
    )

    # hooks for the learner
    if cfg.splade.model == "splade_doc":
        hooks = [
            setmeta(
                DistributedHook(models=[spladev2.encoder]),
                True,
            )
        ]
    else:
        hooks = [
            setmeta(
                DistributedHook(models=[spladev2.encoder, spladev2.query_encoder]),
                True,
            )
        ]

    # establish the validation listener
    validation = ValidationListener(
        id="bestval",
        dataset=ds_val,
        # a retriever which use the splade model to score all the
        # documents and then do the retrieve
        retriever=spladev2.getRetriever(
            base_retriever_full,
            cfg.retrieval.batch_size_full_retriever,
            PowerAdaptativeBatcher(),
            device=device,
        ),
        early_stop=cfg.splade.early_stop,
        validation_interval=cfg.splade.validation_interval,
        metrics={"nDCG@10": True, "RR": False, "nDCG@3": False, "AP@10": False, "R@10": False},
        store_last_checkpoint=True if cfg.splade.model == "splade_doc" else False,
    )

    # the learner: Put the components together
    learner = Learner(
        # Misc settings
        random=random,
        device=device,
        # How to train the model
        trainer=pointwise_trainer_flops,
        # the model to be trained
        model=spladev2.tag("model", "splade-v2"),
        # Optimization settings
        optimizers=cfg.splade.optimization.optimizer,
        steps_per_epoch=cfg.splade.optimization.steps_per_epoch,
        use_fp16=True,
        max_epochs=cfg.splade.optimization.max_epochs,
        # the listener for the validation
        listeners=[validation],
        # the hooks
        hooks=hooks,
    )

    # submit the learner and build the symbolique link
    outputs = learner.submit(launcher=gpu_launcher_learner)
    #tensorboard_service.add(learner, learner.logpath)

    # get the trained model
    trained_model = (
        outputs.listeners["bestval"]["last_checkpoint"]
        if cfg.splade.model == "splade_doc"
        else outputs.listeners["bestval"]["nDCG@10"]
    )

    # build a retriever for the documents
    sparse_index = SparseRetrieverIndexBuilder(
        batch_size=512,
        batcher=PowerAdaptativeBatcher(),
        encoder=DenseDocumentEncoder(scorer=trained_model),
        device=device,
        documents=documents,
        ordered_index=False,
    ).submit(launcher=gpu_launcher_index)

    # Build the sparse retriever based on the index
    splade_retriever = SparseRetriever(
        index=sparse_index,
        topk=1000,
        batchsize=1,
        encoder=DenseQueryEncoder(scorer=trained_model),
    )

    # evaluate the best model
    tests.evaluate_retriever(
        splade_retriever,
        gpu_launcher_retrieval
    )

    return PaperResults(
        models={f"{cfg.splade.model}-{cfg.splade.dataset}-nDCG@10": trained_model},
        evaluations=tests,
        tb_logs={f"{cfg.splade.model}-{cfg.splade.dataset}-nDCG@10": learner.logpath},
    )


@paper_command(schema=SPLADE, package=__package__)
def cli(xp: experiment, cfg: SPLADE):
    return run(xp, cfg, tensorboard_service=True)
