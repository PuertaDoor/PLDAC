from .. import Experiment

# Experiments
PAPERS = [
    Experiment(
        "spladeV2",
        "spaldeV2 models, could be run with different config",
        "experiment:cli",
    )
]
