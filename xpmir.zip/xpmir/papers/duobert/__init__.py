from .. import Experiment

# Experiments
PAPERS = [
    Experiment("msmarco", "duo-BERT trained on MS-Marco passages", "experiment:cli")
]
